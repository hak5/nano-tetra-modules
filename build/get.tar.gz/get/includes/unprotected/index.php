<html>
<head>
<meta http-equiv="REFRESH" content="0;url=redirect.php">
</head>
<body>
</body>
</html>