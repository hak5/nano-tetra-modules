# PortalAuth
Captive portal cloner and payload distributor for the WiFi Pineapple NANO and TETRA
