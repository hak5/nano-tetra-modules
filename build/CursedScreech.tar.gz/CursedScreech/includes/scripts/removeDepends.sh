#!/bin/sh

#  Author: sud0nick
#  Date:   Jan 2016

opkg remove zip > /dev/null;
