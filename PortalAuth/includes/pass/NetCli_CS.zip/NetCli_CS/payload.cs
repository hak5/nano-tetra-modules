using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PineappleModules;

namespace Payload {
    public partial class Form1 : Form {
        public Form1() {
			
			// Create a new instance of PA_Authorization
			PA_Authorization pauth = new PA_Authorization();
			
            // Request an access key from the Pineapple
			string key = pauth.getAccessKey();

			// Check if a key was returned
			string msg;
			if (key.Length > 0) {
				msg = "Your access key is unique to you so DO NOT give it away!\n\nAccess Key: " + key;
			}
			else {
				msg = "Failed to retrieve access key from server.  Please try again later.";
			}

			// Display message to the user
			MessageBox.Show(msg);
			
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e) {
            e.Cancel = true;
            this.Hide();
        }
    }
}